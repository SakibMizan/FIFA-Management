module.exports = {
    //...
    plugins: [require("daisyui")],
  }
